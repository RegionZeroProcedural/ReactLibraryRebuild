import React from 'react'
import Cart from './Cart';

export default function Checkout() {
    let shipping = 0;
  return (
    <div id="books__body">
        <div id="books__main">
            <div className="checkout">
                <h2>Checkout</h2>
                <div className="paymentDetails">
                    <input type="text" className="name__first" />
                    <input type="text" className="name__last" />
                    <input type="number" className="card__number" />
                    <input type="date" className="card__exp" />
                    <input type="number" className="card__pin" />
                    <input type="number" className="zip--card" />
                </div>
                <div className="address__shipping">
                    <input type="text" className="country" />
                    <input type="text" className="street" />
                    <input type="text" className="city" />
                    <input type="text" className="state" />
                    <input type="text" className="zip--shipping" />
                </div>
                <div className="address__billing">
                    <input type="text" className="country--billing" />
                    <input type="text" className="street--billing" />
                    <input type="text" className="city--billing" />
                    <input type="text" className="state--billing" />
                    <input type="text" className="zip--billing" />
                </div>
                <div className="totals">
                    <div className="subtotal">{Cart.subtotal}</div>
                    <div className="tax">{Cart.tax}</div>
                    <div className="shipping">{shipping = calcShipping()}</div>
                    <div className="grandtotal">{Cart.total + shipping}</div>
                </div>
                <div className="confirm">

                </div>
            </div>
        </div>
    </div>
  )
}

function calcShipping() {
    const shipping = 7.99;
    return shipping;
}